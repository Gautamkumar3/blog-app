export const GET_COMMENT_LOADING="COMMENT/get/loading"
export const GET_COMMENT_ERROR="COMMENT/get/error"
export const GET_COMMENT_SUCCESS="COMMENT/get/success"


export const ADD_COMMENT_LOADING="COMMENT/add/loading"
export const ADD_COMMENT_ERROR="COMMENT/add/error"
export const ADD_COMMENT_SUCCESS="COMMENT/add/success"


export const UPDATE_COMMENT_LOADING="COMMENT/update/loading"
export const UPDATE_COMMENT_ERROR="COMMENT/update/error"
export const UPDATE_COMMENT_SUCCESS="COMMENT/update/success"

export const DELETE_COMMENT_LOADING="COMMENT/delete/loading"
export const DELETE_COMMENT_ERROR="COMMENT/delete/error"
export const DELETE_COMMENT_SUCCESS="COMMENT/delete/success"