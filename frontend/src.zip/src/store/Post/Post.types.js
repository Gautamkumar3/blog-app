export const GET_POST_LOADING = "post/get/loading"
export const GET_POST_ERROR = "post/get/error"
export const GET_POST_SUCCESS = "post/get/success"


export const ADD_POST_LOADING = "post/add/loading"
export const ADD_POST_ERROR = "post/add/error"
export const ADD_POST_SUCCESS = "post/add/success"


export const UPDATE_POST_LOADING = "post/update/loading"
export const UPDATE_POST_ERROR = "post/update/error"
export const UPDATE_POST_SUCCESS = "post/update/success"

export const DELETE_POST_LOADING = "post/delete/loading"
export const DELETE_POST_ERROR = "post/delete/error"
export const DELETE_POST_SUCCESS = "post/delete/success"


