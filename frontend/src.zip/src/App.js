
import './App.css';
import Navbar from './components/Navbar';
import Allroute from './route/Allroute';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Allroute />
    </div>
  );
}

export default App;
